from maix import camera, display, image, time, app
from maix.v1.machine import UART
from gui import GUI
import cv2
import numpy as np
import json
import os
# 模式标记
Mode_dir = 3
Mode_dir2 = 3
t = 1
t2 = 1
class Mode:
    circle = 0
    shizi = 1
    
class ValueMode:
    Min = 0
    Max = 1

gui = GUI()

_btn_mode = -1
_btn_ch1 = -1
_btn_ch2 = -1
_btn_ch3 = -1
_btn_binary = -1
_btn_wb = -1
_slider_id = -1    
_wb_requested = False
_wb_status = '白平衡:待校准'
_wb_profile = None
WB_ROI = (128, 88, 64, 64)  # 白纸采样框，坐标基于320×240取景图
CIRCLE_MIN_AREA = 1200
CIRCLE_MIN_PERIMETER = 120
Yuanxy = [0, 0, 0, 0, 0]
Wthreshold = [(100, 255)]

# 圆环阈值：
Threshold = [
    [(0, 32, -20, 20, -20, 20)]
]
# 提前计算常量
PI_FACTOR = 4 * 3.14159


_context = {
    'mode': Mode.circle,
    'value_mode': ValueMode.Min,
    'current_ch': 1,

    'disp_binary': True,

    'threshold_lab': [0, 32, -20, 20, -20, 20],
    'threshold_circle':[50,150]
}


def valid_wb_gains(gains):
    return len(gains) == 4 and all(0 < float(value) <= 1 for value in gains)


def load_white_balance(cam):
    global _wb_profile, _wb_status
    path = os.path.join(app.get_app_data_path(), 'white_balance.json')
    try:
        with open(path, 'r', encoding='utf-8') as config:
            profile = json.load(config)
        if profile['version'] != 1 or not valid_wb_gains(profile['gains']):
            raise ValueError('白平衡参数无效')
        if not valid_wb_gains(cam.set_wb_gain(profile['gains'])):
            raise ValueError('相机未应用白平衡参数')
        _wb_profile = profile
        _wb_status = '白平衡:已加载'
    except FileNotFoundError:
        pass
    except Exception as error:
        _wb_status = '白平衡:加载失败'
        print('白平衡加载失败:', error)


def calibrate_white_balance(cam):
    global _wb_profile, _wb_status
    previous_gains = None
    previous_mode = None
    try:
        previous_mode = cam.awb_mode()
        previous_gains = list(cam.set_wb_gain())
        if not valid_wb_gains(previous_gains):
            raise ValueError('相机白平衡增益无效')
        gains = previous_gains[:]
        x, y, width, height = WB_ROI
        # 手动保持增益，分轮测量白纸并使红、蓝通道向绿色通道收敛。
        for attempt in range(5):
            gains = list(cam.set_wb_gain(gains))
            if not valid_wb_gains(gains):
                raise ValueError('相机未应用白平衡增益')
            cam.skip_frames(5)
            samples = []
            for _ in range(3):
                frame = image.image2cv(cam.read(), True, True)
                patch = frame[y:y + height, x:x + width]
                if patch.shape[:2] != (height, width):
                    raise ValueError('白纸采样框超出画面')
                if np.mean(np.max(patch, axis=2) >= 250) > 0.03:
                    raise ValueError('白纸过曝')
                if np.max(np.std(patch, axis=(0, 1))) > 30:
                    raise ValueError('请用均匀白纸覆盖中心框')
                samples.append(np.median(patch, axis=(0, 1)))
            b, g, r = np.mean(samples, axis=0)
            if min(b, g, r) < 30 or max(b, g, r) > 245:
                raise ValueError('白纸亮度超出校准范围')
            if max(b, g, r) / min(b, g, r) <= 1.08:
                break
            gains[0] *= float(g / r)
            gains[3] *= float(g / b)
            if not valid_wb_gains(gains):
                raise ValueError('白平衡校准增益超出范围')
        else:
            raise ValueError('白平衡未收敛，请检查白纸和光照')

        profile = {'version': 1, 'gains': gains, 'white_level': float((b + g + r) / 3)}
        directory = app.get_app_data_path()
        os.makedirs(directory, exist_ok=True)
        path = os.path.join(directory, 'white_balance.json')
        # 临时文件落盘后替换，保存完成后同步设备存储。
        with open(path + '.tmp', 'w', encoding='utf-8') as config:
            json.dump(profile, config)
            config.flush()
            os.fsync(config.fileno())
        os.replace(path + '.tmp', path)
        if hasattr(os, 'sync'):
            os.sync()
        _wb_profile = profile
        _wb_status = '白平衡:已保存'
    except Exception as error:
        _wb_status = '白平衡:校准失败'
        print('白平衡校准失败:', error)
        try:
            if previous_gains is not None and valid_wb_gains(previous_gains):
                cam.set_wb_gain(previous_gains)
            if previous_mode is not None:
                cam.awb_mode(previous_mode)
        except Exception as restore_error:
            print('白平衡恢复失败:', restore_error)


def rgb_to_lab(r, g, b):
    # 将 RGB 转换为 BGR 格式（OpenCV 默认顺序）
    bgr_pixel = np.uint8([[[b, g, r]]])
    
    # 转换为 Lab（输入需为 BGR 且范围 [0, 255]）
    lab_pixel = cv2.cvtColor(bgr_pixel, cv2.COLOR_BGR2LAB)
    l, a, b = lab_pixel[0][0]
    
    # OpenCV 的 Lab 范围：
    # L: [0, 100] → 映射到 [0, 255]，需转换回 [0, 100]
    # a: [42, 226] → 对应 [-128, 127]
    # b: [20, 223] → 对应 [-128, 127]
    l = int(l * (100 / 255))
    a = a - 128
    b = b - 128
    return l, a, b




def btn_pressed(btn_id, state):
    '''
    按键回调函数，按键按下的时候会自动调用
    '''
    global _btn_mode, _btn_ch1, _btn_ch2, _btn_ch3, _btn_binary, _slider_id, _context
    global _wb_requested, _wb_status
    if state == 1:
        return

    text = ''
    if btn_id == _btn_mode:
        if _context['mode'] == Mode.shizi:
            text = '3'
            _context['mode'] = Mode.circle
            gui.setButtonLabel(_btn_ch1, 'C Min')
            gui.setButtonLabel(_btn_ch2, '')
            gui.setButtonLabel(_btn_ch3, '')
            gui.setSliderLabel(_slider_id, '')
        else:
            text = '2'
            _context['mode'] = Mode.shizi
            gui.setButtonLabel(_btn_ch1, 'L Min')
            gui.setButtonLabel(_btn_ch2, 'A Min')
            gui.setButtonLabel(_btn_ch3, 'B Min')
            gui.setSliderLabel(_slider_id, 'L Min')
        gui.setButtonLabel(btn_id, text)
        _context['current_ch'] = 1
        _context['value_mode'] = ValueMode.Min
    elif btn_id == _btn_ch1:
        if _context['value_mode'] == ValueMode.Min:
            _context['value_mode'] = ValueMode.Max
            if _context['mode'] == Mode.shizi:
                text = 'L Max'
                slider_value = _context['threshold_lab'][1] 
            else:
                text = 'C Max'
                slider_value = int(_context['threshold_circle'][1]/255*100)
        else:
            _context['value_mode'] = ValueMode.Min
            if _context['mode'] == Mode.shizi:
                text = 'L Min'
                slider_value = _context['threshold_lab'][0]
            else:
                text = 'C Min'
                slider_value = int(_context['threshold_circle'][0]/255*100)
        gui.setButtonLabel(btn_id, text)
        gui.setSliderLabel(_slider_id, text)
        gui.setSliderValue(_slider_id, slider_value)
        _context['current_ch'] = 1
    elif btn_id == _btn_ch2:
        if _context['value_mode'] == ValueMode.Min:
            _context['value_mode'] = ValueMode.Max
            if _context['mode'] == Mode.shizi:
                text = 'A Max'
                slider_value = int((_context['threshold_lab'][3] + 128)/255*100)
            else:
                text = ''
                slider_value = 0
        else:
            _context['value_mode'] = ValueMode.Min
            if _context['mode'] == Mode.shizi:
                text = 'A Min'
                slider_value = int((_context['threshold_lab'][2] + 128)/255*100) 
            else:
                text = ''
                slider_value = 0
        gui.setButtonLabel(btn_id, text)
        gui.setSliderLabel(_slider_id, text)
        gui.setSliderValue(_slider_id, slider_value)
        _context['current_ch'] = 2 
    elif btn_id == _btn_ch3:
        if _context['value_mode'] == ValueMode.Min:
            _context['value_mode'] = ValueMode.Max
            if _context['mode'] == Mode.shizi:
                text = 'B Max'
                slider_value = int((_context['threshold_lab'][5] + 128)/255*100) 
            else:
                text = ''
                slider_value = 0
        else:
            _context['value_mode'] = ValueMode.Min
            if _context['mode'] == Mode.shizi:
                text = 'B Min'
                slider_value = int((_context['threshold_lab'][4] + 128)/255*100) 
            else:
                text = ''
                slider_value = 0
        gui.setButtonLabel(btn_id, text)  
        gui.setSliderLabel(_slider_id, text)
        gui.setSliderValue(_slider_id, slider_value)
        _context['current_ch'] = 3
    elif btn_id == _btn_binary:
        _context['disp_binary'] = not _context['disp_binary']     
    elif btn_id == _btn_wb:
        _wb_requested = True
        _wb_status = '白平衡:校准中'

def slider_changed(slider_id, value):
    '''
    滑块值改变后的回调函数，会自动调用
    '''
    global _context

    if _context['mode'] == Mode.shizi:
        if _context['value_mode'] == ValueMode.Min:
            if _context['current_ch'] == 1:
                _context['threshold_lab'][0] = value
            elif _context['current_ch'] == 2:
                _context['threshold_lab'][2] = int(-128 + value*255/100)
            elif _context['current_ch'] == 3:
                _context['threshold_lab'][4] = int(-128 + value*255/100)
        else:
            if _context['current_ch'] == 1:
                _context['threshold_lab'][1] = value
            elif _context['current_ch'] == 2:
                _context['threshold_lab'][3] = int(-128 + value*255/100)
            elif _context['current_ch'] == 3:
                _context['threshold_lab'][5] = int(-128 + value*255/100)
    else:
        if _context['value_mode'] == ValueMode.Min:
            if _context['current_ch'] == 1:
                _context['threshold_circle'][0] = int(value/100*255)
            
        else:
            if _context['current_ch'] == 1:
                _context['threshold_circle'][1] = int(value/100*255)
           
                


class Comm:  # 串口类
    def __init__(self):
        uart = UART("/dev/ttyS0", 115200)
        time.sleep_ms(100)  # wait uart ready
        self.uart = uart
        self.Data_Temp = [0, 0]

    def send_detect(self, Mode, Data):  # 发送数据包
        print("send ok!")
        data = None
        if Mode == 1:
            data = bytes([0xb3, 0xb3, 0x01, int(Data[0]), int(Data[1]), int(Data[2]), int(Data[3]), 0, 0x5b])
            self.uart.write(data)
        if Mode == 2:
            data = bytes([0xb3, 0xb3, 0x02, int(Data[0]), int(Data[1]), int(Data[2]), int(Data[3]), 0, 0x5b])
            self.uart.write(data)
        if Mode == 3:
            data = bytes([0xb3, 0xb3, 0x03, int(Data[0]), int(Data[1]), int(Data[2]), int(Data[3]), int(Data[4]), 0x5b])
            self.uart.write(data)
        if Mode == 4:
            data = bytes([0xb3, 0xb3, 0x04, int(Data), 0, 0, 0, 0, 0x5b])
            self.uart.write(data)
        if Mode == 5:
            data = bytes([0xb3, 0xb3, 0x04, 6, 6, 6, 6, 6, 0x5b])
            self.uart.write(data)
        if data != None:
            print("send_data:", data)

    def read_detect(self):  # 接受数据
        # print('RX_Data True')
        data = self.uart.read()
        print('data:', data)
        if data == b'\x01':
            data = 1
        elif data == b'\x02':
            data = 2
        elif data == b'\x03':
            data = 3
        elif data == b'\x04':
            data = 4
        elif data == b'\x05':
            data = 5
        elif data == b'\x06':
            data = 6
        else:
            data = 0
        print('data:', data)
        return data


def camera_Init():
    cam = camera.Camera(320, 240)
    cam.skip_frames(30)  # 等待摄像头稳定
    return cam
def camera_Init2():
    cam1 = camera.Camera(320, 240)
    cam1.skip_frames(30)  # 等待摄像头稳定
    return cam1




def Getshizi(img, comm):
    img.dilate(4)
    img.mean(1)
    img.erode(3)
    global Yuanxy
    global Wthreshold
    center_x = 0
    center_y = 0
    max_blob = None
    cl = img.find_blobs(Wthreshold, area_threshold=3000, merge=False)
    for c in cl:
        if c:
            # 1. 计算圆形度（roundness），要求小于0.65
            roundness = c.roundness()
            if roundness >= 0.6:
                continue  # 圆形度过高，跳过
            
            # 2. 获取矩形框并检查宽高比（近似相等）
            rect = c.rect()  # 获取矩形框 [x, y, width, height]
            width = rect[2]
            height = rect[3]
            
            # 避免除零错误
            if width == 0 or height == 0 :
                continue
                
            # 计算宽高比（取较小值除以较大值，确保结果在0-1之间）
            aspect_ratio = min(width, height) / max(width, height)
            
            # 宽高比大于0.8视为近似相等（可根据需要调整）
            if aspect_ratio < 0.65:
                continue  # 宽高比不符，跳过
            
            # 3. 更新最大色块
            if max_blob is None or c.area() > max_blob.area():
                max_blob = c  # 更新最大色块

    if max_blob != None:
        center_x = max_blob.cx()
        center_y = max_blob.cy()

        img.draw_rect(max_blob.rect()[0], max_blob.rect()[1], max_blob.rect()[2], max_blob.rect()[3],
                      color=image.COLOR_RED, thickness=2)
        img.draw_cross(int(center_x), int(center_y), color=image.COLOR_RED, size=10, thickness=2)
        Yuanxy = [0, 0, 0, 0, 0]
        Yuanxy[1] = int(center_x)
        Yuanxy[3] = int(center_y)
        if Yuanxy[1] > 255:
            Yuanxy[0] = Yuanxy[1] - 255
            Yuanxy[1] = 255
        if Yuanxy[3] > 255:
            Yuanxy[2] = Yuanxy[3] - 255
            Yuanxy[3] = 255

        comm.send_detect(0x02, Yuanxy)

        msg1 = ""
        msg1 += "center_x:{} \ncenter_Y:{}".format(Yuanxy[1] + Yuanxy[0], Yuanxy[2] + Yuanxy[3])
        print(msg1)
        img.draw_string(220, 160, msg1, image.COLOR_RED, scale=0.9)
        msg2 = ""
        msg2 += "mode:{}".format(Mode_dir)
        img.draw_string(230, 200, msg2, image.COLOR_RED, scale=1.2)
        

def GetYuan(img, comm):
    img.dilate(4)
    img.mean(1)
    img.erode(3)
    global Yuanxy
    global Wthreshold
    center_x = 0
    center_y = 0
    max_blob = None
    cl = img.find_blobs(Wthreshold, area_threshold=2500, merge=False)
    for c in cl:
        if c:
            # 1. 计算圆形度（roundness），要求小于0.65
            roundness = c.roundness()
            if roundness >= 0.6:
                continue  # 圆形度过高，跳过
            
            # 2. 获取矩形框并检查宽高比（近似相等）
            rect = c.rect()  # 获取矩形框 [x, y, width, height]
            width = rect[2]
            height = rect[3]
            
            # 避免除零错误
            if width == 0 or height == 0 or width >= 160 or height >= 160:
                continue
                
            # 计算宽高比（取较小值除以较大值，确保结果在0-1之间）
            aspect_ratio = min(width, height) / max(width, height)
            
            # 宽高比大于0.8视为近似相等（可根据需要调整）
            if aspect_ratio < 0.8:
                continue  # 宽高比不符，跳过
            
            # 3. 更新最大色块
            if max_blob is None or c.area() > max_blob.area():
                max_blob = c  # 更新最大色块
    if max_blob != None:
        center_x = max_blob.cx()
        center_y = max_blob.cy()

        img.draw_rect(max_blob.rect()[0], max_blob.rect()[1], max_blob.rect()[2], max_blob.rect()[3],
                      color=image.COLOR_RED, thickness=2)
        img.draw_cross(int(center_x), int(center_y), color=image.COLOR_RED, size=10, thickness=2)
        Yuanxy = [0, 0, 0, 0, 0]
        Yuanxy[1] = int(center_x)
        Yuanxy[3] = int(center_y)
        if Yuanxy[1] > 255:
            Yuanxy[0] = Yuanxy[1] - 255
            Yuanxy[1] = 255
        if Yuanxy[3] > 255:
            Yuanxy[2] = Yuanxy[3] - 255
            Yuanxy[3] = 255

        comm.send_detect(0x02, Yuanxy)

        msg1 = ""
        msg1 += "center_x:{} \ncenter_Y:{}".format(Yuanxy[1] + Yuanxy[0], Yuanxy[2] + Yuanxy[3])
        print(msg1)
        msg2 = ""
        msg2 += "mode:{}".format(Mode_dir)
        img.draw_string(0, 280, msg2, image.COLOR_RED, scale=1.2)



def GetYuan_cv_3_2(img, comm, disp, kernel,gui):
    global Yuanxy
    avg_center_x = 0  # 平均中心X坐标
    avg_center_y = 0  # 平均中心Y坐标
    img_cv = image.image2cv(img, False, False)  
    
    # 转灰度
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY) 
    # 高斯模糊去噪声
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    # 边缘检测
    edged = cv2.Canny(blurred, _context['threshold_circle'][0], _context['threshold_circle'][1])
    # 膨胀与腐蚀处理
    dilated = cv2.dilate(edged, kernel, iterations=1)
    ceroded = cv2.erode(dilated, kernel, iterations=1)
    # 将单通道的ceroded转换为三通道BGR格式（便于显示和后续叠加彩色标记）
    ceroded_rgb = cv2.cvtColor(ceroded, cv2.COLOR_GRAY2BGR)
    # 找轮廓
    contours, _ = cv2.findContours(ceroded, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    # 圆度阈值
    min_circularity = 0.7

    # 存储所有符合条件的圆形中心
    circle_centers = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        perimeter = cv2.arcLength(cnt, True)

        # 过滤小轮廓和周长为0的异常轮廓
        if perimeter < 190 or area < 2210 or perimeter == 0 or perimeter>555:#175 485 0 815
            continue
        
        # 计算圆度
        circularity = 4 * np.pi * area / (perimeter **2)
        if circularity > min_circularity:
            # 拟合椭圆，获取中心坐标
            center, axes, angle = cv2.fitEllipse(cnt)
            circle_centers.append(center)  # 保存中心坐标(x,y)
            
            # 绘制所有符合条件的圆（便于调试）
            cv2.ellipse(ceroded_rgb, (center, axes, angle), (255, 0, 0), 3)

    if circle_centers:
        # 提取所有圆心的y坐标
        ys = [c[1] for c in circle_centers]
        # 最上方圆的y坐标（最小值，因为y越小越靠上）
        min_y = min(ys)
        # 计算每个圆心y坐标与最上方圆心y坐标的差值
        y_diffs = [y - min_y for y in ys]
        
        # 找出差值大于25像素的圆心（可能的错误圆）
        error_indices = [i for i, diff in enumerate(y_diffs) if diff > 25]
        
        # 仅当存在且仅存在1个错误圆时，剔除该圆
        if len(error_indices) == 1:
            filtered_centers = [c for i, c in enumerate(circle_centers) if i not in error_indices]
        else:
            filtered_centers = circle_centers  # 无错误圆或不符合条件，保留所有圆
        
        # 计算过滤后圆心的平均坐标
        xs_filtered = [c[0] for c in filtered_centers]
        ys_filtered = [c[1] for c in filtered_centers]
        avg_center_x = sum(xs_filtered) / len(xs_filtered)
        avg_center_y = sum(ys_filtered) / len(ys_filtered)
        
        # 在处理后的图像上标记平均中心
        cv2.drawMarker(ceroded_rgb, (int(avg_center_x), int(avg_center_y)), 
                    (255, 0, 0), cv2.MARKER_CROSS, 20, 3)

    if circle_centers:  # 存在圆形时才更新数据
        # 保存平均中心坐标
        Yuanxy = [0, 0, 0, 0, 0]
        Yuanxy[1] = int(avg_center_x)
        Yuanxy[3] = int(avg_center_y)
        if Yuanxy[1] > 255:
            Yuanxy[0] = Yuanxy[1] - 255
            Yuanxy[1] = 255
        if Yuanxy[3] > 255:
            Yuanxy[2] = Yuanxy[3] - 255
            Yuanxy[3] = 255

        comm.send_detect(0x02, Yuanxy)

    # # 打印平均中心信息
    # total = len(circle_centers)
    #     # 在处理后的图像上绘制文本信息
    # cv2.putText(ceroded_rgb, 
    #             f"center_x:{Yuanxy[1]+Yuanxy[0]}", 
    #             (100, 15), 
    #             cv2.FONT_HERSHEY_SIMPLEX, 
    #             0.3, (255, 0, 0), 1)
    # cv2.putText(ceroded_rgb, 
    #             f"center_y:{Yuanxy[3]+Yuanxy[2]}", 
    #             (100, 30), 
    #             cv2.FONT_HERSHEY_SIMPLEX, 
    #             0.3, (255, 0, 0), 1)
    # cv2.putText(ceroded_rgb, 
    #             f"total:{total}", 
    #             (100, 45),  
    #             cv2.FONT_HERSHEY_SIMPLEX, 
    #             0.3, (255, 0, 0), 1)  
    # cv2.putText(ceroded_rgb, 
    #             f"mode:{Mode_dir}", 
    #             (100, 125), 
    #             cv2.FONT_HERSHEY_SIMPLEX, 
    #             0.3, (255, 0, 0), 1)
    # #显示处理后的图像
    # img_show = image.cv2image(ceroded_rgb, False, False)  
    # if _context['mode'] == Mode.circle:
    #     img_show.draw_string(65, 20, '阈值    :{:4d},{:4d}'
    #                     .format(_context['threshold_circle'][0],
    #                     _context['threshold_circle'][1],
    #                     ), image.COLOR_BLUE)   
    # gui.run(img_show)


def GetYuan_cv_3_2_3(img, comm, disp, kernel,gui, fps):
    global Yuanxy
    avg_center_x = 0  # 平均中心X坐标
    avg_center_y = 0  # 平均中心Y坐标
    img_cv = image.image2cv(img, True, True)
    
    # 转灰度
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY) 
    # 高斯模糊去噪声
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    # 边缘检测
    edged = cv2.Canny(blurred, _context['threshold_circle'][0], _context['threshold_circle'][1])
    # 小范围连接边缘，并保留原始边缘像素。
    ceroded = cv2.morphologyEx(edged, cv2.MORPH_CLOSE, kernel, iterations=1)
    ceroded = cv2.bitwise_or(ceroded, edged)
    # 将单通道的ceroded转换为三通道BGR格式（便于显示和后续叠加彩色标记）
    ceroded_rgb = cv2.cvtColor(ceroded, cv2.COLOR_GRAY2BGR)
    if not _context['disp_binary']:
        ceroded_rgb = img_cv.copy()
    # 找轮廓
    contours, _ = cv2.findContours(ceroded, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    # 圆度阈值
    min_circularity = 0.7

    # 存储所有符合条件的圆形中心
    circle_centers = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        perimeter = cv2.arcLength(cnt, True)

        # 过滤小轮廓和周长为0的异常轮廓
        if (len(cnt) < 5 or perimeter < CIRCLE_MIN_PERIMETER
                or area < CIRCLE_MIN_AREA or perimeter > 555):
            continue
        
        # 计算圆度
        circularity = 4 * np.pi * area / (perimeter **2)
        if circularity > min_circularity:
            # 拟合椭圆，获取中心坐标
            center, axes, angle = cv2.fitEllipse(cnt)
            circle_centers.append(center)  # 保存中心坐标(x,y)
            
            # 绘制所有符合条件的圆（便于调试）
            cv2.ellipse(ceroded_rgb, (center, axes, angle), (255, 0, 0), 3)

    if circle_centers:
        # 提取所有圆心的y坐标
        ys = [c[1] for c in circle_centers]
        # 最上方圆的y坐标（最小值，因为y越小越靠上）
        min_y = min(ys)
        # 计算每个圆心y坐标与最上方圆心y坐标的差值
        y_diffs = [y - min_y for y in ys]
        
        # 找出差值大于25像素的圆心（可能的错误圆）
        error_indices = [i for i, diff in enumerate(y_diffs) if diff > 25]
        
        # 仅当存在且仅存在1个错误圆时，剔除该圆
        if len(error_indices) == 1:
            filtered_centers = [c for i, c in enumerate(circle_centers) if i not in error_indices]
        else:
            filtered_centers = circle_centers  # 无错误圆或不符合条件，保留所有圆
        
        # 计算过滤后圆心的平均坐标
        xs_filtered = [c[0] for c in filtered_centers]
        ys_filtered = [c[1] for c in filtered_centers]
        avg_center_x = sum(xs_filtered) / len(xs_filtered)
        avg_center_y = sum(ys_filtered) / len(ys_filtered)
        
        # 在处理后的图像上标记平均中心
        cv2.drawMarker(ceroded_rgb, (int(avg_center_x), int(avg_center_y)), 
                    (255, 0, 0), cv2.MARKER_CROSS, 20, 3)

    if circle_centers:  # 存在圆形时才更新数据
        # 保存平均中心坐标
        Yuanxy = [0, 0, 0, 0, 0]
        Yuanxy[1] = int(avg_center_x)
        Yuanxy[3] = int(avg_center_y)
        if Yuanxy[1] > 255:
            Yuanxy[0] = Yuanxy[1] - 255
            Yuanxy[1] = 255
        if Yuanxy[3] > 255:
            Yuanxy[2] = Yuanxy[3] - 255
            Yuanxy[3] = 255

        comm.send_detect(0x02, Yuanxy)

    # 打印平均中心信息
    total = len(circle_centers)
        # 在处理后的图像上绘制文本信息
    cv2.putText(ceroded_rgb, 
                f"center_x:{Yuanxy[1]+Yuanxy[0]}", 
                (100, 15), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.6, (255, 0, 0), 1)
    cv2.putText(ceroded_rgb, 
                f"center_y:{Yuanxy[3]+Yuanxy[2]}", 
                (100, 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.6, (255, 0, 0), 1)
    cv2.putText(ceroded_rgb, 
                f"total:{total}", 
                (100, 45),  
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.6, (255, 0, 0), 1)  
    cv2.putText(ceroded_rgb, 
                f"mode:{Mode_dir}", 
                (100, 125), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.6, (255, 0, 0), 1)
    x, y, width, height = WB_ROI
    cv2.rectangle(ceroded_rgb, (x, y), (x + width, y + height), (0, 255, 255), 1)
    # 下方80像素用于触摸控件，FPS按文字宽度贴右下角排列。
    screen = np.zeros((320, 320, 3), dtype=np.uint8)
    screen[:ceroded_rgb.shape[0], :ceroded_rgb.shape[1]] = ceroded_rgb
    cv2.putText(screen, 'v1.0.1', (246, 233),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1)
    fps_text = f"FPS:{fps}"
    (text_width, text_height), baseline = cv2.getTextSize(fps_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)
    cv2.putText(screen, fps_text, (screen.shape[1] - text_width - 5, screen.shape[0] - baseline - 5),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 1)
    img_show = image.cv2image(screen, True, True)
    img_show.draw_string(65, 242, _wb_status, image.COLOR_GREEN)
    if _context['mode'] == Mode.circle:
        img_show.draw_string(65, 20, '阈值    :{:4d},{:4d}'
                        .format(_context['threshold_circle'][0],
                        _context['threshold_circle'][1],
                        ), image.COLOR_BLUE)   
    gui.run(img_show)


def GetYuan_cv(img, comm, disp, kernel,gui):
    global Yuanxy
    avg_center_x = 0  # 平均中心X坐标
    avg_center_y = 0  # 平均中心Y坐标
    img_cv = image.image2cv(img, False, False)  
    
    # 转灰度
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY) 
    # 高斯模糊去噪声
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    # 边缘检测
    edged = cv2.Canny(blurred, _context['threshold_circle'][0], _context['threshold_circle'][1])
    # 膨胀与腐蚀处理
    dilated = cv2.dilate(edged, kernel, iterations=1)
    ceroded = cv2.erode(dilated, kernel, iterations=1)
    # 将单通道的ceroded转换为三通道BGR格式（便于显示和后续叠加彩色标记）
    ceroded_rgb = cv2.cvtColor(ceroded, cv2.COLOR_GRAY2BGR)
    # 找轮廓
    contours, _ = cv2.findContours(ceroded, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    # 圆度阈值
    min_circularity = 0.7

    # 存储所有符合条件的圆形中心
    circle_centers = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        perimeter = cv2.arcLength(cnt, True)

        # 过滤小轮廓和周长为0的异常轮廓
        if perimeter < 175 or area < 1500 or perimeter == 0 or perimeter>815:#175 485 0 815
            continue
        
        # 计算圆度
        circularity = 4 * np.pi * area / (perimeter **2)
        if circularity > min_circularity:
            # 拟合椭圆，获取中心坐标
            center, axes, angle = cv2.fitEllipse(cnt)
            circle_centers.append(center)  # 保存中心坐标(x,y)
            
            # 绘制所有符合条件的圆（便于调试）
            cv2.ellipse(ceroded_rgb, (center, axes, angle), (255, 0, 0), 3)

    # 计算平均中心（如果存在圆形）
    if circle_centers:
        # 提取所有X和Y坐标
        xs = [c[0] for c in circle_centers]
        ys = [c[1] for c in circle_centers]
        # 计算平均值
        avg_center_x = sum(xs) / len(xs)
        avg_center_y = sum(ys) / len(ys)
        # 在处理后的图像上标记平均中心
        cv2.drawMarker(ceroded_rgb, (int(avg_center_x), int(avg_center_y)), 
                      (255, 0, 0), cv2.MARKER_CROSS, 20, 3)

    if circle_centers:  # 存在圆形时才更新数据
        # 保存平均中心坐标
        Yuanxy = [0, 0, 0, 0, 0]
        Yuanxy[1] = int(avg_center_x)
        Yuanxy[3] = int(avg_center_y)
        if Yuanxy[1] > 255:
            Yuanxy[0] = Yuanxy[1] - 255
            Yuanxy[1] = 255
        if Yuanxy[3] > 255:
            Yuanxy[2] = Yuanxy[3] - 255
            Yuanxy[3] = 255

        comm.send_detect(0x02, Yuanxy)

    # 打印平均中心信息
    total = len(circle_centers)
        # 在处理后的图像上绘制文本信息
    cv2.putText(ceroded_rgb, 
                f"center_x:{Yuanxy[1]+Yuanxy[0]}", 
                (200, 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.6, (255, 0, 0), 2)
    cv2.putText(ceroded_rgb, 
                f"center_y:{Yuanxy[3]+Yuanxy[2]}", 
                (200, 60), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.6, (255, 0, 0), 2)
    cv2.putText(ceroded_rgb, 
                f"total:{total}", 
                (200, 90),  
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.6, (255, 0, 0), 2)  
    cv2.putText(ceroded_rgb, 
                f"mode:{Mode_dir}", 
                (200, 250), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.8, (255, 0, 0), 2)
    # 显示处理后的图像
    img_show = image.cv2image(ceroded_rgb, False, False)  
    if _context['mode'] == Mode.circle:
        img_show.draw_string(65, 20, '阈值    :{:4d},{:4d}'
                        .format(_context['threshold_circle'][0],
                        _context['threshold_circle'][1],
                        ), image.COLOR_BLUE)   
    gui.run(img_show)
    
    
    






comm = Comm()  # 串口初始化

###########################################  主函数  ################################################

def main():
    global Mode_dir
    global Mode_dir2
    global comm
    global Yuanxy
    global _btn_mode,_btn_ch1, _btn_ch2, _btn_ch3, _btn_binary, _btn_wb, _slider_id
    global _wb_requested
     # 摄像头初始化
    disp_width  = 320
    disp_height = 320
    global t
    global t2
    cam = camera_Init()  # 摄像头初始化
    cam1 = camera_Init2()  # 摄像头初始化
    load_white_balance(cam1)
    # 闭运算卷积核
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5))
    kernel_mode3 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3))
    # 创建按钮
    button_height = disp_height//5
    button_width  = 60
    _btn_mode = gui.createButton(0, 0, button_width, button_height, '3')
    gui.setButtonCallback(_btn_mode, btn_pressed)

    _btn_ch1 = gui.createButton(0, button_height, button_width, button_height, 'C Min')
    gui.setButtonCallback(_btn_ch1, btn_pressed)

    _btn_ch2 = gui.createButton(0, 2*button_height, button_width, button_height, '')
    gui.setButtonCallback(_btn_ch2, btn_pressed)

    _btn_ch3 = gui.createButton(0, 3*button_height, button_width, button_height, '')
    gui.setButtonCallback(_btn_ch3, btn_pressed)

    _btn_binary = gui.createButton(0, 4*button_height, button_width, button_height, '显示')
    gui.setButtonCallback(_btn_binary, btn_pressed)

    _btn_wb = gui.createButton(210, 263, 104, 28, '白平衡')
    gui.setButtonCallback(_btn_wb, btn_pressed)

    # 创建滑动条
    _slider_id = gui.createSlider(80, 294, 140, 18, label='C Min')
    gui.setSliderCallback(_slider_id, slider_changed)
    #disp = display.Display()

    while True:
       
    
        
        # 模式
        if Mode_dir == 2:
            cam.skip_frames(30)  # 等待摄像头稳定
            while True:
                t = time.ticks_ms()
                img= cam.read()  # 读取一张图片
                # img = cam.read().binary([_context['threshold_lab']], invert=False, zero=False)
                Mode_dir2 = comm.read_detect()
                if Mode_dir2 == 3:
                    _context['mode'] = Mode.circle
                if _context['mode'] == Mode.circle :   
                    Mode_dir=3
                if Mode_dir == 1 or Mode_dir == 3 or _context['mode'] == Mode.circle:
                    break
                GetYuan_cv_3_2(img, comm,gui._disp,kernel,gui)
                
                t2 = time.ticks_ms() - t
                print(int(1000.0 / t2))
                # if not _context['disp_binary']:
                #      # 1. 获取图像
                #     imgyuan = cam.read()
                #     # 3. 获取触摸点颜色值
                #     pixel_x = disp_width//2
                #     pixel_y = disp_height//2
                #     pixel = imgyuan.get_pixel(pixel_x, pixel_y, True)
                #     if _context['mode'] == Mode.shizi:
                #         value_l,value_a,value_b = rgb_to_lab(pixel[0], pixel[1], pixel[2])
                #         img.draw_string(65, 5, '颜色值:{:4d},{:4d},{:4d}'.format(value_l, value_a, value_b), image.COLOR_RED)    
                #     img.draw_cross(pixel_x, pixel_y, image.COLOR_BLUE, 5)  


                #     # 4. 图像显示及GUI框架刷新
                #     if _context['mode'] == Mode.shizi:
                #         img.draw_string(65, 20, '阈值    :{:4d},{:4d},{:4d},{:4d},{:4d},{:4d}'
                #                                         .format(_context['threshold_lab'][0],
                #                                         _context['threshold_lab'][1],
                #                                         _context['threshold_lab'][2],
                #                                         _context['threshold_lab'][3],
                #                                         _context['threshold_lab'][4],
                #                                         _context['threshold_lab'][5]), image.COLOR_BLUE)
                # gui.run(img)

        elif Mode_dir == 3:
            cam1.skip_frames(30)  # 等待摄像头稳定
            fps = 0
            while True:
                if _wb_requested:
                    _wb_requested = False
                    calibrate_white_balance(cam1)
                t = time.ticks_ms()
                img= cam1.read()  # 读取一张图片
                
                Mode_dir2 = comm.read_detect()
                if Mode_dir2 == 2:
                    _context['mode'] = Mode.shizi
                if _context['mode'] == Mode.shizi :   
                    Mode_dir=2
                if Mode_dir == 1 or Mode_dir == 2 or _context['mode'] == Mode.shizi:
                    break
                GetYuan_cv_3_2_3(img, comm,gui._disp,kernel_mode3,gui, fps)
                #disp.show(img)
                
                t2 = time.ticks_ms() - t
                fps = int(1000.0 / max(t2, 1))
                print(fps)
                
if __name__ == "__main__":
    main()
